package array;

public class IntegerArray {

	
	public static void main(String[] args) {
		
		int sum = 0,temp;
		int A[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
		
		for(int i=0; i<=14; i++) {
			
			 sum = sum + A[i];
		}
		A[15]=sum;
		
		System.out.println("Array after adding 15th element");
		for(int i=0; i< 18; i++ ) {
			System.out.print(A[i] + " ");
		}
		
		A[16]=(sum+A[15])/18;
		System.out.println("\n");
		System.out.println("Array after adding 16th element");
		for(int i=0; i< 18; i++ ) {
			System.out.print(A[i] + " ");
		}
		
		int B[] = new int [A.length];
		
		for (int i = 0; i < A.length; i++) {
            B[i] = A[i];
		}
		for (int i = 0; i < 17; i++)   
        {  
            for (int j = i + 1; j < 17; j++)   
            {  
                if (B[i] > B[j])   
                {  
                    temp = B[i];  
                    B[i] = B[j];  
                    B[j] = temp;  
                }  
            }  
        }  
		A[17] = B[0];
		
		System.out.println("\n");
		System.out.println("Array after adding 17th element");
		for(int i=0; i< 18; i++ ) {
			System.out.print(A[i] + " ");
		}
	}

}
