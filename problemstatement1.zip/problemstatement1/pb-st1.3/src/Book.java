
public class Book {
	public String title;
	public int price;
	public Book(String title,int price)
	
	{
	 
		this.title = title;
		this.price = price;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public void show()

    {

        getTitle();

        
        getPrice();

    }    
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Book b1=new Book("Java Programming",350);

		b1.show();
		Book b2=new Book("Let Us C",200);
		b2.show();
	}

}
