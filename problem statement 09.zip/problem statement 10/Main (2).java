import java.util.HashMap;
import java.util.Map;

class Main
{
	// Function to find the frequency of each element in a sorted array
	public static Map<Integer, Integer> findFrequency(int[] nums)
	{
		// Map to store the frequency of each array element
		Map<Integer, Integer> freq = new HashMap<>();

		// search space is nums[left…right]
		int left = 0, right = nums.length - 1;

		// loop till the search space is exhausted
		while (left <= right)
		{
			// if nums[left…right] consists of only one element, update its count
			if (nums[left] == nums[right])
			{
				freq.put(nums[left], freq.getOrDefault(nums[left], 0) +
						(right - left + 1));

				// now discard nums[left…right] and continue searching in
				// nums[right+1… n-1] for nums[left]
				left = right + 1;
				right = nums.length - 1;
			}
			else {
				// reduce the search space
				right = (left + right) / 2;
			}
		}

		return freq;
	}

	public static void main(String[] args)
	{
		int[] nums = { 2, 2, 2, 4, 4, 4, 5, 5, 6, 8, 8, 9};

		Map<Integer, Integer> freq = findFrequency(nums);
		System.out.println(freq);
	}
}